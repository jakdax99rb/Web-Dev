If you want to run this locally just throw it in whatever www folder you are using. Other wise go to this link https://codd.cs.gsu.edu/~jbaird5/WP/PW/index.php. 

Project Presentation Link: https://youtu.be/Aaa8uR3En8A